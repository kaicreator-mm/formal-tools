# Why3 R27 reproducible evidence bundle

This bundle contains the initial R27 scoped replay (`original-r27/`) and an independent second replay of the same R27 input bytes (`independent-rerun/`). The second replay is not the missing historical R23 `/tmp` input/log bundle.

## Independent rerun results
- Why3 1.8.0 validation-only candidate + Z3 5.4.0.
- Solver commands executed in a filesystem chroot as UID/GID 65534:65534. A fresh private `/tmp` file was owned by 65534:65534; an attempted write into the Why3 package tree was denied. Host `/usr/lib/x86_64-linux-gnu/ocaml` remained absent.
- POS: `Valid`, exit 0.
- NEG: `Unknown (sat)`, exit 2. This is not `Invalid` and not an independently validated counterexample.
- ERR: Why3 parser syntax error, exit 1.
- Exact inputs, raw stdout/stderr, command records, exit files and checksums are under `independent-rerun/`.

## Provenance and limits
- Why3 archive is a validation-only candidate, not an official publisher package. Original unsafe Why3 archive remains quarantined and was not executed.
- Z3 official GitHub release ZIP and separate binary-only tar have different archive digests and contents; extracted Z3 executable bytes are identical. See `independent-rerun-manifest.json`.
- Automatic Why3 detection does not recognize Z3 5.4.0. The replay uses an explicit manual `z3_487` driver configuration; broad compatibility is not established.
- User-namespace isolation is not established. Network namespace isolation is unavailable; network isolation is NOT_PROVEN. Host runtime libraries were copied into the private chroot.

Research replay only. No T1/T2/T3/T4/T5/T6, Product or Release qualification is granted. No current-main Runner/Registry/CLI/MCP/SDK execution is included.
