# Why3 R27 scoped non-root chroot replay

This evidence is a new, reproducible R27 run. It does not claim to reproduce the missing historical R23 `/tmp` input bytes or raw logs. The R23 values are retained only as historical writer-reported metadata and are not used as independently verified evidence.

## Run scope
- Why3 1.8.0 validation-only sanitized candidate archive; candidate SHA-256 is recorded in `r27-manifest.json`.
- Z3 5.4.0 official GitHub release ZIP, downloaded through Drive and byte-checked against the GitHub release API digest. A separate binary-only Z3 tar package is also recorded; both contain the same Z3 executable bytes, but their archive digests and package contents differ.
- The solver commands ran inside a filesystem chroot as UID/GID 65534:65534. Host runtime libraries were copied into the private rootfs. No host `/usr` path was modified.
- Unprivileged network namespace creation was unavailable (`unshare -n` returned EPERM); network isolation is NOT_PROVEN. User-namespace isolation is NOT_CLAIMED for this run.
- Why3 automatic detection does not recognize Z3 5.4.0. The proof replay uses an explicit manual configuration with the packaged `z3_487` driver; it does not establish general Z3 5.4.0 compatibility.

## Results
- POS: `Valid`, exit 0.
- NEG: `Unknown (sat)`, exit 2. This is not Why3 `Invalid` and is not claimed as a formally validated counterexample.
- ERR: Why3 parser syntax error, exit 1.

The exact `.mlw` input bytes, raw stdout/stderr streams, manual and detector configs, metadata outputs, and checksums are committed alongside this file. These are research-only execution receipts, not T0/T1/T2/T3/T4/T5/T6, Product, or Release qualification.
