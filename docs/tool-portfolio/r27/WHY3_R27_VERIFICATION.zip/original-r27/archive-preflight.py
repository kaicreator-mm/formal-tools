#!/usr/bin/env python3
"""Read-only tar.zst and ZIP member preflight for the R27 Why3/Z3 assets."""
import os, pathlib, stat, subprocess, sys, tarfile, zipfile

def tar_check(path):
    proc=subprocess.Popen(["zstd","-dc",path],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    names=set(); counts={"regular_files":0,"directories":0,"relative_symlinks":0}; errors=[]
    with tarfile.open(fileobj=proc.stdout,mode="r|") as tf:
        for m in tf:
            p=pathlib.PurePosixPath(m.name)
            if p.is_absolute() or ".." in p.parts or m.name in names: errors.append({"name":m.name,"reason":"absolute/traversal/duplicate"})
            names.add(m.name)
            if m.isfile(): counts["regular_files"]+=1
            elif m.isdir(): counts["directories"]+=1
            elif m.issym():
                counts["relative_symlinks"]+=1
                t=pathlib.PurePosixPath(m.linkname)
                resolved=pathlib.PurePosixPath(os.path.normpath(str(p.parent/t)))
                if t.is_absolute() or ".." in resolved.parts: errors.append({"name":m.name,"target":m.linkname,"reason":"absolute/escaping symlink"})
            else: errors.append({"name":m.name,"reason":"special/hardlink/unsupported"})
    err=proc.stderr.read().decode(errors="replace") if proc.stderr else ""
    rc=proc.wait()
    return {"members":len(names),**counts,"unsafe":errors,"zstd_exit":rc,"zstd_stderr":err}

def zip_check(path):
    counts={"regular_files":0,"directories":0,"relative_symlinks":0}; errors=[]
    with zipfile.ZipFile(path) as z:
        for i in z.infolist():
            p=pathlib.PurePosixPath(i.filename); mode=(i.external_attr>>16)&0xffff
            if p.is_absolute() or ".." in p.parts: errors.append({"name":i.filename,"reason":"absolute/traversal"})
            if stat.S_ISLNK(mode):
                counts["relative_symlinks"]+=1; target=pathlib.PurePosixPath(z.read(i).decode(errors="replace"))
                resolved=pathlib.PurePosixPath(os.path.normpath(str(p.parent/target)))
                if target.is_absolute() or ".." in resolved.parts: errors.append({"name":i.filename,"reason":"absolute/escaping symlink"})
            elif i.is_dir(): counts["directories"]+=1
            else: counts["regular_files"]+=1
    return {"members":sum(counts.values()),**counts,"unsafe":errors}

if __name__=="__main__":
    import json
    print(json.dumps({"why3_candidate":tar_check(sys.argv[1]),"z3_repacked_tar":tar_check(sys.argv[2]),"z3_official_zip":zip_check(sys.argv[3])},indent=2,sort_keys=True))
